class Cliente():
    def __init__(self, nome,login,senha,CEP,rua,bairro,numero,email,telefone):
        self.__nome = nome
        self.__login = login
        self.__senha = senha
        self.__cep = CEP
        self.__rua = rua
        self.__bairro = bairro
        self.__numero = numero
        self.__email = email
        self.__telefone = telefone
        
    
    @property
    def nome(self):
        return self.__nome

    @property
    def login(self):
        return self.__login

    @property
    def senha(self):
        return self.__senha
        
    @property
    def cep(self):
        return self.__cep

    @property
    def rua(self):
        return self.__rua

    @property
    def bairro(self):
        return self.__bairro

    @property
    def numero(self):
        return self.__numero

    @property
    def email(self):
        return self.__email

    @property
    def telefone(self):
        return self.__telefone