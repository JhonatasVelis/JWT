from infra.db import con
from wrap_connection import transact 
from model.cliente import Cliente

sql_criar = "INSERT INTO Cliente(nome,login,senha, CEP,RUA,BAIRRO,NUMERO,EMAIL,TELEFONE) VALUES(?,?,?,?,?,?,?,?,?)"
sql_consultar = "SELECT nome,login,senha, CEP,RUA,BAIRRO,NUMERO,EMAIL,TELEFONE FROM CLIENTE"
sql_verificarLogin = "SELECT nome,login,senha, CEP,RUA,BAIRRO,NUMERO,EMAIL,TELEFONE FROM CLIENTE WHERE login = ? AND senha = ?"

@transact(con)
def criar(Cliente):
    cursor.execute(sql_criar, (Cliente.nome,Cliente.login,Cliente.senha,Cliente.cep, Cliente.rua,Cliente.bairro,Cliente.numero,Cliente.email,Cliente.telefone))
    connection.commit()

@transact(con)
def listar():
    cursor.execute(sql_consultar)
    resultado = []
    for r in cursor:
        resultado.append(Cliente(r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8])) 
    return resultado
    connection.commit()

@transact(con)
def varificarLogin(login,senha):
    cursor.execute(sql_verificarLogin,(login,senha))
    resultado = []
    for r in cursor:
        resultado.append(Cliente(r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8])) 
    return resultado
    connection.commit()
'''
@transact(con)
def criar(login):
    cursor.execute(sql_consultar, login, senha)
    connection.commit()
'''
