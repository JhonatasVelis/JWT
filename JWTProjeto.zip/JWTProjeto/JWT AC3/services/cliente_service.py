from model.cliente import Cliente
from infra.log import Log

from dao.cliente_dao import criar as criar_dao, listar as listar_dao, varificarLogin as verificarLogin_dao

def criar(nome,login,senha,cep,rua,bairro,numero,email,telefone):
    criado = Cliente(nome,login,senha,cep,rua,bairro,numero,email,telefone)
    criar_dao(criado)
    return criado

def listar():
    clientes = listar_dao()
    return clientes

def verificarLogin(login,senha):
    return verificarLogin_dao(login,senha)
     
