import sqlite3

create_sql = [

"""
CREATE TABLE IF NOT EXISTS CLIENTE(
    ID INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    login TEXT,
    senha TEXT NOT NULL,
    CEP TEXT NOT NULL,
    RUA TEXT NOT NULL,
    BAIRRO TEXT,
    NUMERO TEXT,
    EMAIL TEXT,
    TELEFONE TEXT
);
"""
]

from wrap_connection import transact


def con():
    return sqlite3.connect('banco.db')

@transact(con)
def criar_db():
    for script in create_sql:
        cursor.execute(script)
    connection.commit()
    