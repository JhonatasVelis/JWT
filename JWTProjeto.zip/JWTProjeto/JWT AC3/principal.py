from infra.to_dict import to_dict, to_dict_list
from flask import Flask, jsonify, request
from cliente import cliente_app
from infra.db import criar_db

app = Flask(__name__)
app.register_blueprint(cliente_app)

criar_db()

if __name__ == '__main__':
    app.run(host='localhost', port=5000, debug = True)
