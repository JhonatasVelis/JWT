from JWT import create_jwt,verify_and_decode_jwt, iniciandoJWT
from flask_cors import CORS
from flask import Blueprint, jsonify, request
from infra.validacao import validar_campos
from infra.to_dict import to_dict, to_dict_list
from services.cliente_service import criar as service_criar, listar as service_listar, verificarLogin as service_verficarLogin
    

cliente_app = Blueprint('cliente_app',  __name__)

CORS(cliente_app)
campos = ["id", "nome"]
tipos = [int, str]

@cliente_app.route('/cliente',methods=['POST'])
def criar():
    dados = request.get_json()
    criado = service_criar(dados['nome'], dados['login'],dados['senha'],dados['cep'],dados['rua'],dados['bairro'],dados['numero'],dados['email'],dados['telefone'])
    return jsonify(to_dict(criado))

@cliente_app.route('/cliente', methods=['GET'])
def listar():
    jwt = request.headers.get('Token')
    retornoVD = verify_and_decode_jwt(jwt)
    if retornoVD == 'OK':
        lista = service_listar()
        return jsonify(to_dict_list(lista))
    return retornoVD

@cliente_app.route('/cliente/login', methods=['POST'])
def verficarLogin():
    dados = request.get_json()
    criado = service_verficarLogin(dados['login'], dados['senha'])
    if len(criado) == 0:
        return 'Usuário ou senha inválidos', 401
    return iniciandoJWT()
